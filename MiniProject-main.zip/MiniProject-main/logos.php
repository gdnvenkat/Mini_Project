<div className="flex justify-center">
            <img src = "img/Museum.jpeg" alt="indian museum" width="100" height="100"/>
            <img src = "img/Ministry_of_Culture_India.png" alt ="ministry" width="200" height="100" />
            <img src = "img/75azadi.png" alt="azaadi ka amrit mahotsav" width="200" height="100" />
            <img src = "img/G20.png" alt="G20" width="200" height="100"/>
        </div>